from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from django.contrib.auth.hashers import make_password
from django.db.models import Q

from accounts.models import Role, User, UserRole
from events.models import Event
from payments.models import EventCollectionTransaction
from django.db.models import Sum, Max
from accounts.serializer import (
    UserGetSerializer,
    UserCreateSerializer,
    UserUpdateSerializer,
    UserDeleteSerializer
)
from common.api.base_api import BaseAuthenticatedAPI
from accounts.serializer import UserRoleCreateSerializer
from common.responses import api_response_success, api_response_error

class UserListAPI(BaseAuthenticatedAPI):
    """
    GET:
    Returns list of all active users with optional filtering and search.
    Supports search filter on name and email.
    Used in Admin User Management screen.
    """

    def get(self, request):

        error = self.require_admin_role(request)
        if error:
            return error
        
        page_no = int(request.query_params.get('pageNo', 1))
        page_size = int(request.query_params.get('pageSize', 10))
        search_filter = request.query_params.get('search', '').strip()

        qs = User.objects.filter(is_active=True).order_by('-created_at')
        
        # Apply search filter
        if search_filter:
            qs = qs.filter(
                Q(full_name__icontains=search_filter) | 
                Q(email__icontains=search_filter)
            )
        
        # Get total count before pagination
        total_count = qs.count()
        
        offset = (page_no - 1) * page_size
        users = qs[offset:offset + page_size]

        serializer = UserGetSerializer(users, many=True)
        return self.paginated_response(
            data=serializer.data,
            page_no=page_no,
            page_size=page_size,
            total_record=total_count,
            message="Users retrieved successfully"
        )
    
class UserDetailAPI(APIView):
    """
    GET:
    Returns single user details by user ID.
    Used for View / Edit user screen.
    """

    def get(self, request, user_id):
        try:
            # Fetch user by ID
            user = User.objects.get(id=user_id, is_active=True)
        except User.DoesNotExist:
            return api_response_error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )

        serializer = UserGetSerializer(user)

        # ===== Events the user has created =====
        created_events = Event.objects.filter(created_by=user, is_active=True)

        # ===== Events the user has joined (via payments) =====
        joined_event_ids = EventCollectionTransaction.objects.filter(
            user=user,
            is_active=True
        ).values_list('event_id', flat=True).distinct()

        joined_events = Event.objects.filter(id__in=list(joined_event_ids), is_active=True)

        # Build event list with role and payment aggregates
        events = []

        # Helper to compute payment aggregates for a user & event
        def payment_aggregates(ev, usr):
            qs = EventCollectionTransaction.objects.filter(event=ev, user=usr, is_active=True)
            total_paid = qs.aggregate(total=Sum('amount'))['total'] or 0
            last_tx = qs.aggregate(last_date=Max('transaction_date'))['last_date']
            tx_count = qs.count()
            return {
                'total_paid': str(total_paid),
                'last_payment_date': last_tx,
                'transaction_count': tx_count,
            }

        # Include created events (organiser)
        for ev in created_events:
            agg = payment_aggregates(ev, user)
            events.append({
                'event_id': ev.id,
                'title': ev.title,
                'role': 'organiser',
                'payment': agg,
            })

        # Include joined events where user is participant (avoid duplicates)
        created_ids = {e['event_id'] for e in events}
        for ev in joined_events:
            if ev.id in created_ids:
                # user is organiser and participant; mark organiser already added
                continue
            agg = payment_aggregates(ev, user)
            events.append({
                'event_id': ev.id,
                'title': ev.title,
                'role': 'participant',
                'payment': agg,
            })

        data = serializer.data
        data['events'] = events

        return api_response_success(data=data)

class UserCreateAPI(APIView):
    """
    POST:
    Creates a new user.
    Password is hashed before saving.
    """

    def post(self, request):
        serializer = UserCreateSerializer(data=request.data)
        if serializer.is_valid():
            data = serializer.validated_data

            # Create user with hashed password
            user = User.objects.create(
                full_name=data['full_name'],
                email=data['email'],
                contact_no=data['contact_no'],
                password_hash=make_password(data['password']),
                status=1,
                is_active=True
            )

            return api_response_success(
                data={"user_id": user.id},
                message="User created successfully",
                status_code=status.HTTP_201_CREATED
            )

        return api_response_error(
            message="Validation failed",
            data=serializer.errors,
            status_code=status.HTTP_400_BAD_REQUEST
        )

class UserUpdateAPI(APIView):
    """
    PUT:
    Updates user basic details.
    """

    def put(self, request, user_id):
        try:
            user = User.objects.get(id=user_id, is_active=True)
        except User.DoesNotExist:
            return api_response_error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )

        serializer = UserUpdateSerializer(user, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return api_response_success(
                message="User updated successfully",
                status_code=status.HTTP_200_OK
            )

        return api_response_error(
            message="Validation failed",
            data=serializer.errors,
            status_code=status.HTTP_400_BAD_REQUEST
        )


class UserDeleteAPI(APIView):
    """
    PATCH:
    Soft deletes a user by setting is_active = False.
    No data is permanently removed.
    """

    def patch(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return api_response_error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )

        # Soft delete
        user.is_active = False
        user.save()

        return api_response_success(
            message="User deleted successfully",
            status_code=status.HTTP_200_OK
        )


class AssignUserRoleAPI(BaseAuthenticatedAPI):
    """
    POST:
    Assigns a role to a user.
    Only one active role per user is allowed.
    Admin access required.
    """

    def post(self, request):
        # Step 1: Ensure admin access
        error = self.require_admin_role(request)
        if error:
            return error

        # Step 2: Validate input (user_id, role_id)
        serializer = UserRoleCreateSerializer(data=request.data)
        if not serializer.is_valid():
            return api_response_error(
                message="Validation failed",
                data=serializer.errors,
                status_code=status.HTTP_400_BAD_REQUEST
            )

        user_id = serializer.validated_data['user'].id
        role_id = serializer.validated_data['role'].id

        # Step 3: Validate user existence
        try:
            user = User.objects.get(id=user_id, is_active=True)
        except User.DoesNotExist:
            return api_response_error(
                message="User not found",
                status_code=status.HTTP_404_NOT_FOUND
            )

        # Step 4: Validate role existence
        try:
            role = Role.objects.get(id=role_id, is_active=True)
        except Role.DoesNotExist:
            return api_response_error(
                message="Role not found",
                status_code=status.HTTP_404_NOT_FOUND
            )

        # Step 5: Deactivate existing roles for user
        UserRole.objects.filter(
            user=user,
            is_active=True
        ).update(is_active=False)

        # Step 6: Assign new role
        UserRole.objects.create(
            user=user,
            role=role,
            is_active=True
        )

        return api_response_success(
            message="Role assigned to user successfully",
            status_code=status.HTTP_200_OK
        )
