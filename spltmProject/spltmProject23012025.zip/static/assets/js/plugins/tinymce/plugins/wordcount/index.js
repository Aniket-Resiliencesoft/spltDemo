// Exports the "wordcount" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/wordcount')
//   ES2015:
//     import 'tinymce/plugins/wordcount'
require('./plugin.js');